Anyprint
========

Do you commonly forget what language you're writing while typing contrived
print statements? This is the module for you!

Usage
-----

Simply import this module:

```python
import anyprint
```

Which makes the following valid python:

```python
printf("printf %d\n", 10);

fmt.Println("hello")

cout << "Hello, C++!" << endl;

Print["Hello from Mathematica!"]

console.log("yes");

io.write("lua land")

System.out.printf("java stuff\n");

System.Console.WriteLine("C# looks awkard");

Ada.Text_IO.Put_Line("Ada is cool")

IO.puts("elixir")

putStrLn("Pure lazy Haskell!")
```

Anyprint supports a growing number of languages, and welcomes more!

Testimonials
------------

Anyprint has many glowing reviews from its many satisfied users:

>"omg pls"

>"what is wrong with you"

>"That's stupid and not useful."

>"Please add my testimonial: \"very accurate testimonials\"."

>"kragniz, please stop writing questionable python metamodules :v"

>"can I have a testimonial?"

>"pls add my testimonial: no memes guaranteed."

>"The Testimonials section cracked me up."
